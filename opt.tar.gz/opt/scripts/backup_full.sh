#! /bin/bash


WHITE="\e[1;37m"
BLUE="\e[1;34m"
LG="\e[0;32m"
NC="\e[0m"

EXECUTION_LOGS="/opt/scripts/backup_execution_logs"

log_execution() {
	echo "$1" | tee -a "$EXECUTION_LOGS"
}

validar_directorios() {
		  DIRECTORIOS_VALIDOS="T"
		  if ! [[ -d "$ORIGEN" ]]; then
			  DIRECTORIOS_VALIDOS="F"
			  log_execution "El Origen no es un directorio"
		  fi
		  if ! [[ -d "$DESTINO" ]]; then
			  DIRECTORIOS_VALIDOS="F"
			  log_execution "El Destino no es un directorio"
		  fi
		  if [[ "$DIRECTORIOS_VALIDOS" = "F" ]]; then
			  exit 1
		  fi

		  echo "Los directorios recibidos son validos" >> "$EXECUTION_LOGS"
}

# Valido que el flag que se reciba
if [[ "$1" =~ -.* ]] && [[ "$1" != "-help" ]]; then
	echo -e "${WHITE}$1 ${NC}no es una opcion valida"
	exit 1
fi

# Muestro manual de uso si ingresan el flag -help
while [[ "$1" == "-help" ]]; do
	echo -e "${BLUE}backup_full"
	echo -e "${WHITE}NOMBRE"
	echo -e "	${NC}backup_full - comprime y copia directorios objetivo"
	echo -e "${WHITE}SINOPSIS"
	echo -e "	${WHITE}backup_full ${NC}[${LG}OPCION${NC}]... ${LG} ORIGEN DESTINO"
	echo -e "	${WHITE}OPCIONES${NC}"
	echo -e "		${WHITE} -help ${NC} muestra este menu. Con ${WHITE}q ${NC} se sale"
	read -p "Ingrese q para salir " opt
	case "$opt" in
		q) break; exit 1;;
		*) continue;;
	esac 
done

FECHA_Y_HORA=$(date +%Y-%m-%dT%H:%M)
FECHA=$(date +%Y%m%d)

echo "=============== ${FECHA_Y_HORA} - Backup inicializado ================" >> "$EXECUTION_LOGS"

# Chequear que se recibieron dos argumentos
if [[ $# -ne 2 ]]; then
	log_execution "Faltan argumentos para poder ejecutar el backup"
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Validar que existan origen y destino
validar_directorios "$ORIGEN" "$DESTINO"

# Comprimir origen
NOMBRE_DIRECTORIO=$(basename "$ORIGEN")
NOMBRE_FILE_COMPRIMIDO="${DESTINO}/${NOMBRE_DIRECTORIO}_bckp_${FECHA}.tar.gz"

cd "$ORIGEN"
tar -cvzf "${NOMBRE_FILE_COMPRIMIDO}" ./

if [[ $? -eq 0  ]]; then
	echo "La compresion fue exitosa" >> "$EXECUTION_LOGS"
else
	log_execution "Hubo un error al comprimir el origen. No se pudo completar el backup"
fi























		
